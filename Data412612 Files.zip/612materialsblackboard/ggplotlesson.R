#Chapter 2 Data Visualization ggplot practice (Tidyverse coding)
library(tidyverse)
mpg
View(mpg)
?mpg
#Lets create a boxplot
ggplot(data = mpg) +
  geom_boxplot(mapping = aes(y=cty))

ggplot(data = mpg) +
  geom_boxplot(mapping = aes(y=cty)) +
  coord_flip()


#Creating side by side boxplots (Show boxplots for highway mileage with respect to levels of a
# character variable)

ggplot(data = mpg) +
  geom_boxplot(mapping = aes(x=drv, y=hwy)) 


# Lets create histogram
ggplot(data = mpg) +
  geom_histogram(mapping = aes(x=cty))  #Tidyverse method

hist(mpg$cty)  #base R method


# Lets create stem and leaf plot
stem(mpg$cty)  # base R method


#bar graph
ggplot(data=mpg) +
  geom_bar(mapping = aes(drv))


# Lets create a scatter plot
plot(mpg$cty ~ mpg$hwy)   # base R method

ggplot(data=mpg) +
  geom_point(mapping = aes(x = cty, y=hwy))   #Tidyverse method


#scatter plot  (change the color of the data points)
ggplot(data=mpg) +
  geom_point(mapping = aes(x = cty, y=hwy), color = "red")

#scatter plot  (reflects patterns for different levels of a categorical variable)
ggplot(data=mpg) +
  geom_point(mapping = aes(x = cty, y=hwy, color = trans))


#scatter plot (adding a title and axis labels to the graph)
ggplot(data = mpg) +
  geom_point(mapping = aes(x=cty, y=hwy)) +
 xlab("city") +
 ylab("highway") +
 ggtitle("milespergallon")
#scatter plot (adding a regression line to your plot)
ggplot(data=mpg) +
  geom_point(mapping = aes(x=cty, y=hwy)) +
  xlab("city") +
  ylab("highway") + 
  ggtitle("milespergallon") +
  geom_smooth(method=lm, mapping=aes(x=cty,y=hwy)) 


#scatter plot (Adding a line that follows the general path of the 
#scatter plot)

ggplot(data=mpg) +
  geom_point(mapping = aes(x = cty, y=hwy)) +
  geom_smooth(mapping = aes(x = cty, y=hwy))


#scatter plot (Producing smooth lines for a specified categorical
#variable)
ggplot(data=mpg) +
  geom_point(mapping = aes(x = displ, y=hwy)) +
  geom_smooth(mapping = aes(x = displ, y=hwy, color = drv))



  




q()
y