library(tidyverse)
library(dplyr)
library(tidyr)
library(readr)


#1
install.packages("devtools")
devtools::install_github("jvcasillas/untidydata")
untidydata::language_diversity->b
b

untidydata::pre_post

#2 and #3
b%>%
pivot_wider( names_from = Measurement
            , values_from = Value)%>%
  arrange(Continent)%>%
  print(n = 40)-> b1
b1

#4
b1%>%
  filter(Continent == "Asia") 
  


?untidydata::pre_post
#5
untidydata::pre_post->PP
PP


#6
PP%>%
  mutate(spec = recode(spec, "g1_lo" = "g1lo", "g2_lo" = "g2lo", "g1_hi" = "g1hi", "g2_hi"=
                       "g2hi"))

#7

# https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master
#/csse_covid_19_data/csse_covid_19_time_series/time_series_covid19_confirmed_global.csv


read_csv("time_series_covid19_confirmed_global.csv")->covid
covid

#8
covid%>%
pivot_longer(cols =c( `1/22/2020`:`10/15/2020`),  names_to = "date",
             values_to = "cases")->covid1
covid1

#9
covid1%>%
  filter(`Country/Region` ==c("Vietnam","Thailand", "Singapore"))-> covid2
covid2



#10
ggplot(data = covid2) +
  geom_bar(mapping = aes(x =`Country/Region`, y = cases, fill = `Country/Region`), stat = "identity")


#11
covid2%>%
  filter(`Country/Region`== "Singapore")->cd2
cd2

sum(cd2$cases)


covid2%>%
  filter(`Country/Region`== "Vietnam")->cd3
cd3

sum(cd3$cases)


covid2%>%
  filter(`Country/Region`== "Thailand")->cd4
cd4

sum(cd4$cases)

           
q()
y

