
library(tidyverse)
library(stringr)

#7) Using the common words of stringr :: words, 
# produce R code that will generate words that end ing or tion.
str_sub(words,  [^"pn$"])

9)  Use a stringr function(s) to find all words that begin with p and end with t


str_subset(words, "^p") -> z
z
str_subset(z, "t$") 

#7

str_subset(words, "(el|al)$")

#10  
sum(str_detect(words,  "v"))