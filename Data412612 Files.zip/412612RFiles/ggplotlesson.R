#Chapter 2 Data Visualization ggplot practice (Tidyverse coding)
library(tidyverse)
mpg
View(mpg)
nrow(mpg)
ncol(mpg)
?mpg  
#Lets create a boxplot for the variable cty(city miles per gallon)
ggplot(data = mpg) +
  geom_boxplot(mapping = aes(y=cty))

# Are there outliers ?
# Estimate the first Quartile 
# Estimate the median
# Estimate the third Quartile

# Find exact calculations
median(mpg$cty)
summary(mpg$cty)

# Lets create the same boxplot using a horizontal representation
ggplot(data = mpg) +
  geom_boxplot(mapping = aes(y=cty)) +
  coord_flip()


#Creating side by side boxplots (Show boxplots for city mileage with 
#respect to levels of the categorical variable drive train (drv)

ggplot(data = mpg) +
  geom_boxplot(mapping = aes(x=drv, y=cty)) 

# Lets create a histogram

hist(mpg$cty)  #base R method

ggplot(data = mpg) +
  geom_histogram(mapping = aes(x=cty))  #Tidyverse method



# Lets create a stem and leaf plot
stem(mpg$cty)  # base R method

# Compare with the histogram
hist(mpg$cty)

#Lets create a bar graph for the categorical variable drv
ggplot(data=mpg) +
  geom_bar(mapping = aes(drv))

# Approximately how many vehicles are front wheel drive ?

# Lets create a scatter plot
plot(mpg$cty ~ mpg$hwy)   # base R method

ggplot(data=mpg) +
  geom_point(mapping = aes(x = cty, y=hwy))   #Tidyverse method


#scatter plot  (change the color of the data points)
ggplot(data=mpg) +
  geom_point(mapping = aes(x = cty, y=hwy), color = "red")

#scatter plot  (reflects patterns for different levels of a categorical variable)
ggplot(data=mpg) +
  geom_point(mapping = aes(x = cty, y=hwy, color = trans))


#scatter plot (adding a title and axis labels to the graph)
ggplot(data = mpg) +
  geom_point(mapping = aes(x=cty, y=hwy)) +
 xlab("city") +
 ylab("highway") +
 ggtitle("milespergallon")


#scatter plot (adding a regression line to your plot)
ggplot(data=mpg) +
  geom_point(mapping = aes(x=cty, y=hwy)) +
  xlab("city") +
  ylab("highway") + 
  ggtitle("milespergallon") +
  geom_smooth(method=lm, mapping=aes(x=cty,y=hwy)) 
 # geom_smooth(method=lm, mapping=aes(x=cty,y=hwy), se = FALSE) 


#scatter plot (Adding a line that follows the general path of the 
#scatter plot)

ggplot(data=mpg) +
  geom_point(mapping = aes(x = cty, y=hwy)) +
  geom_smooth(mapping = aes(x = cty, y=hwy))


#scatter plot (Producing smooth lines for a specified categorical
#variable, levels patters based on color)
ggplot(data=mpg) +
  geom_point(mapping = aes(x = displ, y=hwy)) +
  geom_smooth(mapping = aes(x = displ, y=hwy, color = drv))



#scatter plot (Producing smooth lines for a specified categorical
#variable, level patterns based on line types)
ggplot(data=mpg) +
  geom_point(mapping = aes(x = displ, y=hwy)) +
  geom_smooth(mapping = aes(x = displ, y=hwy, linetype = drv))


#scatter plot (Producing regression lines for a specified categorical
#variable)
ggplot(data=mpg) +
  geom_point(mapping = aes(x = displ, y=hwy)) +
  geom_smooth(method = lm, mapping = aes(x = displ, y=hwy, color = drv),
              se = FALSE)




q()
y