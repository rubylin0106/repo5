

library(tidyverse)
library(stringr)


str_subset(words,  "x$")

str_detect(words, "x$")
words[str_detect(words, "x$")]

# Example  Find all words that start with an a or end with an a.
str_subset(words,  "^a") -> AA
AA


str_subset(AA,  "a$") 


# Find all words that start with a vowel and end with a vowel.

str_subset(words,  "^[aeiou]")-> XX
XX

str_subset(XX,  "[^aeiou]$")


(str_subset(XX,  "[^aeiou]$"))

# Example  Find all words that contain an a and a b

(str_subset(words,  "[a]")) -> yy
yy

(str_subset(yy,  "[b]"))

# What are the words that contain the three vowels a, e, i, and o?
# Are there words that contain at least one of all of the vowels?
(str_subset(words,  "[a]")) -> yy
yy

(str_subset(yy,  "[e]")) ->yyy
yyy   # yyy contains an a and an e


(str_subset(yyy,  "[i]")) -> yyyy
yyyy   # yyyy contains an a, e, and i


(str_subset(yyyy,  "[o]")) 


# Find all seven letter words that have two e's, 
(str_subset(words,  "ee")) -> S
S

str_


q()
y



