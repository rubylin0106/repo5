
# Chapter 13  Dates and Times
library(tidyverse)
library(nycflights13)
library(lubridate)  # new package
library(dplyr)


# Determine the accurate Date using R
today()

# Determine the accurate Date and time using R
now()

# Parsing strings for Dates using lubricate functions

#  year month day

("2020-06-28")   #ymd

("June 28th, 2020")   #mdy

("28th, June, 2020")   #dmy

(20200628)       #ymd

# Parsing strings for Dates and times using lubricate functions

# year month day hours minutes seconds


("2020-06-28 15:14:23" )    # ymd_hms

("06/28/2020 03:24")  # mdy_hm


ymd(20200628, tz ="UTC")    # UTC  Coordinated Universal Time 

# Example: Consolidate elements of dates and time by using coding make_date( ) and 
# make_datetime( )

flights%>%
  select(year,month,day,hour,minute)


flights%>%
  select(year,month,day,hour,minute)%>%
  mutate(
    departure = make_datetime(year,month,day,hour,minute)) 


flights


make_datetime_100 <- function(year, month, day, time) {
  make_datetime(year, month, day, time %/% 100, time %% 100)
}

flights_dt <- flights %>% 
  filter(!is.na(dep_time), !is.na(arr_time)) %>% 
  mutate(
    dep_time = make_datetime_100(year, month, day, dep_time),
    arr_time = make_datetime_100(year, month, day, arr_time),
    sched_dep_time = make_datetime_100(year, month, day, sched_dep_time),
    sched_arr_time = make_datetime_100(year, month, day, sched_arr_time)
  ) %>% 
  select(origin, dest, ends_with("delay"), ends_with("time"))

flights_dt

  
# Using Accessor Functions to extract Date Time components 

  
datetime <- ymd_hms("2020-06-28 14:25:13")
datetime

year(datetime)
month(datetime)
month(datetime, label = TRUE)
mday(datetime)
yday(datetime)
wday(datetime)
wday(datetime, label = TRUE)


# Application of wday

  flights_dt %>% 
  mutate(wday = wday(dep_time, label = TRUE)) %>% 
  ggplot(aes(x = wday)) +
  geom_bar()
  
  
  
  flights_dt%>%
    mutate(wday = wday(dep_time, label = TRUE)) ->mwday
  mwday
  View(mwday)
  
  ggplot(data = mwday)+
    geom_bar(mapping = aes(x = wday, fill = wday))
  
  # Setting Components
  
  # Accessor functions can be used to set components
  
  ymd_hms("2020-06-28 14:16:05") -> datetime
  datetime

# Change the year to 2025
  
 2025-> year(datetime)
 datetime
 
# Change the month to 11
 
11 -> month(datetime)
datetime

# Change multiple components by using update

update(datetime, year = 2019, month = 5, day = 12, hour = 10, minute = 8, second = 22)

# Time Spans
# Durations (exact number of seconds)

dminutes(15)
  
dhours(2)

ddays(1:4)

dseconds(32)

# R can use seconds conversions to add, subtract,multiply , and divide time units.

# Lets add 3 weeks to 8 days by converting to seconds

dweeks(3) + dhours(17)

# Lets subtract 72 seconds from 2 minutes
dminutes(2) - dseconds(72)

# Durations designations have limitations regarding some calculations that involve daylight
# savings time and different time zone considerations.  It is better to use Periods

# Periods  

    seconds(25)
    minutes(7)
    hours(13)
    days(5)
    weeks(2)
    months(9)
    years(3)

# Adding and multiplying with Periods
    years(3) + months(3)
    days(45) + months(2)
    3* days(27)
    
    now() + days(2)
    
    
# Intervals (Should be used because not all time units have the same numberof subtime units)
    
# Example
    
# It should be clear that dyears(1)/ddays(365) approximately 1
    dyears(1)/ddays(365)

# Now consider the computation years(1)/days(1). Intuitively, this answers the question "how many
# days are in a year.  365
    years(1)/days(1)
    
# Some years have 365 days and some years have 366 days!!  You should use Intervals
    next_year <- today() + years(1)
    next_year
    
    (today() %--% next_year)/ddays(1)
    
# If you want to find out how many periods fall into an interval, use %/%
    
    (today() %--% next_year)%/%days(1)
    
    (today() %--% next_year)/months(1)
    


# TIME ZONES
    
OlsonNames()
    
Sys.timezone()



length(OlsonNames())
q()
y
