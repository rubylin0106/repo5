

library(tidyverse)
library(stringr)

#3 Use and show R code to find the common words that end in x using the str_subset string r function 
# and the str_detect function.
str_subset(words,  "x$")

words[str_detect(words, "x$")]

# Example  Find all words that start with an a and end with an a. (there are three such words)
str_subset(words,  "^a") -> AA
AA
str_subset(AA,  "a$") 

str_subset(words,  "^a$")


#2 Find all words that start with a vowel and end with a vowel.

str_subset(words,  "^[aeiou]")-> XX
XX

str_subset(XX,  "[aeiou]$")

# Find all words that start with a vowel and end with a consonant.


(str_subset(XX,  "[^aeiou]$"))

# Example  Find all words that contain an a and a b

(str_subset(words,  "[a]")) -> yy
yy

(str_subset(yy,  "[b]"))


#4 What are the words that contain the three vowels a, e, i, and o?
# Are there words that contain at least one of all of the vowels?
(str_subset(words,  "[a]")) -> yy
yy

(str_subset(yy,  "[e]")) ->yyy
yyy   # yyy contains an a and an e


(str_subset(yyy,  "[i]")) -> yyyy
yyyy   # yyyy contains an a, e, and i


(str_subset(yyyy,  "[o]")) 


# 1
(str_subset(words,  "^....$")) -> one
one

(str_subset(one,  "[v]")) 

stringr::sentences

head(sentences)

#5

str_subset(words,  "[q]") -> s
s
str_subset(s, "[u]")




q()
y



