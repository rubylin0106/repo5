
library(tidyverse)
library(forcats)
library(dplyr)

gss_cat

#1

# As illustrated in the notes and your book, create a factor that will allow you to sort
# the vector given according to value from lowest to highest.  (Show all work and steps; make
# sure that your work makes use of the factor function)

y <- c("ten", "eight", "twelve", "two", "six", "four")
y

levely <- c("two","four", "six", "eight", "ten", "twelve", "fourteen", "sixteen")
levely

factory <- factor(y, levels = levely)
factory

sort(factory)


# 2
# Create a bar graph that will indicate the religion with the highest count.
ggplot(data = gss_cat) +
  geom_bar(mapping = aes(x= relig, fill=relig))

ggplot(data = gss_cat) +
  geom_bar(mapping = aes(x= fct_infreq(relig), fill=fct_infreq(relig)))


# 3
# Use the fct_recode function (along with mutate) to change level Never married to
# Never Married. You are to perform the change on the marital variable of the gss_cat
# data frame.

gss_cat%>%
  mutate(marital = fct_recode(marital,  "Never Married" = "Never married"))

# 4
# use the fct_collapse function to create the table given below for the variable marital of
# the gss_cat data frame.
gss_cat%>%
  mutate(marital = fct_collapse(marital,
   Notmarried= c("Never married", "Separated", "Divorced","Widowed")))%>%
   count(marital)

# 5 

# Use and show R code to create a data table the shows the mean age for every religion shown
# in the gss_cat data frame. A partial table is shown below. Your code should produce a table 
# that shows 15 observations.


gss_cat%>%
  group_by(relig)%>%
  summarize(meanage = mean(age, na.rm = TRUE),
  n=n()      
  ) -> agebyrelig
agebyrelig

# 6

# Use and show R code to produce the scatterplot shown that graphically relates mean age to
# each religion

ggplot(data = agebyrelig) +
  geom_point(mapping = aes(x=meanage,
                           y = relig)) 

# 7 
# Now use the fct_reorder function to improve on the scatter plot produced in #6.  Your scatter
# plot should show a progression of lowest to highest mean ages for each religion.
ggplot(data = agebyrelig) +
  geom_point(mapping = aes(x=meanage,
                           y = fct_reorder(relig, meanage)))

  

