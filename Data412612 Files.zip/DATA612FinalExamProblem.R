

library(tidyverse)
library(stringr)
library(dplyr)

diamonds

diamonds%>%
  select(color)%>%
  count(color)

# Graduate student problems


# To the mpg data table, apply a stringr function to print all 
# observations of the manufacturer variable in upper case letters.
# Then use R coding to produce rows 15 to 25.  The first five 
# rows of the table are shown below.

mpg%>%
  select(manufacturer, model, year) %>%
  mutate(manufacturer = str_to_upper(manufacturer))%>%
  slice(15:25)


# To the diamonds data table, apply R code to produce the table given
# below.  Note that the variable name color has been changed to Color.
diamonds%>%
  select(color)%>%
  count(color)%>%
  rename(Color = color, Frequency = n)%>%
  arrange(desc(Frequency)) -> d2
d2


# Now use ggplot coding to produce the bar graph shown for the 
# table that you produced.
ggplot(data = d2) +
  geom_bar(mapping = aes(y = Frequency, x = Color, fill = Color), 
  stat = "identity") +
  scale_y_continuous(breaks = seq(2500,11500, by =1000))



