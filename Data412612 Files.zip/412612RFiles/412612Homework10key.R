
library(tidyverse)
library(stringr)

#1
#pneumonoultramicroscopicsilicovolcanoconiosis 
X <- "pneumonoultramicroscopicsilicovolcanoconiosis"
X

str_extract(X,  "volcano")
str_extract(X, "picsi..co")

# 2 
str_view(c("abcabc", "abbabb", "abbbab", "abccba"), "(.)(.)(.)\\3\\2\\1" ,
         match = TRUE)


# 3
files = c( "tmp-project.csv", "project.csv", "project2-csv-specs.csv", "project2.csv2.specs.xlsx",
           "project_cars.ods", "project-houses.csv", "Project_Trees.csv","project-cars.R",
           "project-houses.r", "project-final.xls", "Project-final2.xlsx" )
str_subset(files, "xlsx$") 


#4

str_subset(words, "ee$") 

#5
str_view(c("buissdrtb","ablwabs", "mbrm") , "^(.).*\\1$")

#6    "(.)(.)(.).*\\3\\2\\1"  Any word that starts with three letters and end with the
#                             the three letters in reverse order.
         

str_view(c("buissdrtb","abcuerkcba", "mbrm") , "(.)(.)(.).*\\3\\2\\1")

