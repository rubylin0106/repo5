
# 1)  Use and show R code to convert 200 minutes to seconds

dminutes(200)

# 2) Use and show R code to convert 15 hours to seconds

dhours(15)

# 3) Use and show Durations R code to find the total number of seconds
# acquired when adding 7 weeks to 62 hours

dweeks(7) + dhours(62)

# 4) Use and show Periods to multiply 37 months by 5. What is the total
# number of days ?
5* days(37)

# 5) Use and show R code to extract the name of month from the date time
# designation 1956 - 03 - 15 12:32:09

ymd_hms("1956-03-15-12:32:09") -> datetime
datetime

month(datetime, label = TRUE)

 # 6) Use and show R code to produce the accurate Date and Time.

now()

#7
flights%>%
  select(year,month,day,hour,minute)%>%
  mutate(
    arrival = make_datetime(year,month,day,hour,minute))%>%
  filter(year == 2013 , month == 3 , day == 7) -> flights2
flights2

